charmhelpers.contrib.openstack.templates package
================================================

.. automodule:: charmhelpers.contrib.openstack.templates
    :members:
    :undoc-members:
    :show-inheritance:
