Examples
========

If you'd like to contribute an example (please do!), please refer to the
:doc:`contributing` page for instructions on how to do so.

.. toctree::
   :maxdepth: 1
   :glob:

   examples/*
